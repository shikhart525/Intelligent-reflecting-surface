# Intelligent Reflecting Surface (IRS) / Intelligent Metasurface Unit Cell

## Project Title
**Design and ANSYS HFSS Simulation of a Single Intelligent Metasurface / IRS Unit Cell**

## Overview
This repository documents a single-unit-cell electromagnetic design based on the published paper:

**F. Liu et al., "Intelligent Metasurfaces with Continuously Tunable Local Surface Impedance for Multiple Reconfigurable Functions," Physical Review Applied, 11, 044024 (2019).**

The reference design uses a periodic metal-patch structure on a grounded Rogers RT/Duroid 5880 substrate. A tunable lumped R-C load is introduced between the patches to control the local electromagnetic response.

The present project is focused on the **single unit-cell design and ANSYS HFSS electromagnetic simulation**.

## Objectives
- Design the single metasurface/IRS unit cell.
- Implement the geometry and materials described in the reference work.
- Model the tunable R-C loading.
- Set up an electromagnetic simulation in ANSYS HFSS.
- Study the reflection response around 5 GHz.
- Compare the student's HFSS result with the published reference benchmark when actual simulation data are available.

## Reference Geometry

| Parameter | Value |
|---|---:|
| Operating frequency | 5 GHz |
| Unit-cell period, dx | 9.12 mm |
| Unit-cell period, dy | 18.24 mm |
| Patch width, w | 8.12 mm |
| Patch separation, g | 1 mm |
| Substrate thickness, t | 1.016 mm |
| Substrate | Rogers RT/Duroid 5880 |
| Relative permittivity, εr | 2.2 |
| Loss tangent, tanδ | 0.0009 |
| Metalization thickness | 17.5 μm |

## Reference R-C Operating Point

For normal incidence at 5 GHz, the paper reports:
- R = 3.44 Ω
- C = 1.69 pF
- |Γ| = −59.4 dB

This is a **published reference result**, not an independently generated result in this repository.

## HFSS Workflow

1. Create the Rogers RT/Duroid 5880 substrate.
2. Create the continuous copper ground plane.
3. Create the two top copper patches.
4. Maintain the 1 mm gap between patches.
5. Introduce the lumped R-C element across the gap.
6. Apply the appropriate periodic/unit-cell boundaries.
7. Define the Floquet-port excitation.
8. Set a solution frequency around 5 GHz.
9. Perform a frequency sweep around the operating frequency.
10. Export S11 data.
11. Compare the actual HFSS result with the reference benchmark.

## Repository Contents

```text
IRS_HFSS_Final_Submission/
├── README.md
├── REPORT.md
├── CITATION.bib
├── LICENSE
├── .gitignore
├── docs/
│   ├── HFSS_Simulation_Workflow.md
│   └── Submission_Notes.md
├── data/
│   ├── reference_parameters.csv
│   └── HFSS_S11_TEMPLATE.csv
├── results/
│   ├── README.md
│   └── reference_benchmark.csv
├── figures/
│   └── README.md
└── reference/
    └── IRS_Project_Reference_Paper.pdf
```

## Important Result Integrity Note

The repository does **not** fabricate an HFSS curve or numerical result.

The paper's −59.4 dB value is stored as a **reference benchmark**. If this project is being submitted as your own simulation work, the final `results/` folder should contain your exported HFSS S11 data and your HFSS screenshots.

Do not label the published −59.4 dB value as your own simulation result unless you have independently reproduced it.

## Reference
F. Liu et al., Physical Review Applied, 11, 044024 (2019).  
DOI: 10.1103/PhysRevApplied.11.044024
