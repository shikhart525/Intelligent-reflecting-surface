# Project Report

## Design and ANSYS HFSS Simulation of a Single Intelligent Reflecting Surface Unit Cell

### Abstract
This project investigates the electromagnetic behavior of a single intelligent metasurface/Intelligent Reflecting Surface (IRS) unit cell. The design is based on the architecture reported by Liu et al. The structure consists of metallic patches on a grounded Rogers RT/Duroid 5880 substrate with a tunable lumped R-C loading element. The target operating frequency is 5 GHz. The purpose of the work is to reproduce the unit-cell geometry and establish an ANSYS HFSS simulation methodology for evaluating its reflection response.

### 1. Introduction
Intelligent metasurfaces use engineered subwavelength elements to manipulate electromagnetic waves. The reference work demonstrates a microwave metasurface whose local surface impedance can be modified using tunable resistance and capacitance. The reported structure supports tunable electromagnetic functions, including absorption and anomalous reflection.

This project concentrates on the **single unit-cell design and electromagnetic simulation** rather than claiming a complete multi-cell programmable IRS implementation.

### 2. Reference Design
The reference paper specifies a periodic metal-patch topology over a continuous ground plane. The unit cell is designed for operation around 5 GHz.

The reported dimensions are:

| Quantity | Value |
|---|---:|
| dx | 9.12 mm |
| dy | 18.24 mm |
| patch width | 8.12 mm |
| gap | 1 mm |
| substrate thickness | 1.016 mm |
| metal thickness | 17.5 μm |
| εr | 2.2 |
| tanδ | 0.0009 |

The substrate is Rogers RT/Duroid 5880.

### 3. Tunable Load
The reference design incorporates a tunable complex impedance through a resistance and capacitance. The paper explains that capacitance mainly controls the resonance position while resistance affects the absorption level.

For normal incidence at 5 GHz, the paper reports an operating point of:

- R = 3.44 Ω
- C = 1.69 pF
- reflection coefficient = −59.4 dB

The reported tunability ranges are approximately 0–5 Ω for resistance and 1–5 pF for capacitance.

### 4. ANSYS HFSS Model
The intended HFSS model contains:

1. Rogers RT/Duroid 5880 substrate.
2. Copper ground plane on the bottom.
3. Two square copper patches on the top surface.
4. 1 mm gap between the patches.
5. Lumped R-C connection across the gap.
6. Periodic/unit-cell boundary conditions.
7. Floquet-port excitation.
8. Frequency sweep around 5 GHz.

### 5. Simulation Quantity
The principal electromagnetic quantity is the reflection coefficient S11.

For a grounded metasurface, transmission is suppressed by the conducting ground plane. Under this condition, absorption can be related to the reflection coefficient through:

\[
A = 1-|S_{11}|^2
\]

where S11 is converted to linear magnitude before applying the expression.

### 6. Reference Benchmark
The reference paper reports that ANSYS HFSS simulations at normal incidence required:

R = 3.44 Ω

C = 1.69 pF

and produced a reflection coefficient of approximately:

**S11 = −59.4 dB at 5 GHz.**

This value is included only as a **literature benchmark**.

### 7. Student HFSS Results
This section must contain the actual results obtained from the student's HFSS project.

Recommended entries:

| Quantity | Student HFSS Result |
|---|---|
| Resonant/target frequency | To be filled from HFSS |
| Minimum S11 | To be filled from HFSS |
| R | Actual simulated value |
| C | Actual simulated value |
| Absorption | To be calculated from HFSS |
| Frequency sweep | Actual HFSS sweep |

The repository intentionally leaves these fields open because no actual HFSS result file or `.aedt` project was supplied with the source material.

### 8. Discussion
The expected behavior is a strong reduction in reflection near the designed operating frequency when the lumped R-C load is appropriately selected. The reference paper demonstrates that modifying R and C changes the electromagnetic response of the unit cell.

A direct comparison between the student's simulation and the paper should be made only after exporting the student's actual HFSS data.

### 9. Conclusion
A single intelligent metasurface/IRS unit-cell architecture was studied using the geometry and loading concept of a published microwave intelligent-metasurface design. The structure uses Rogers RT/Duroid 5880, copper patches, a continuous ground plane, and a tunable R-C load. ANSYS HFSS provides the electromagnetic simulation framework for evaluating S11 around 5 GHz.

The natural next step is to validate the actual HFSS model against the published benchmark and then extend the unit cell to a multi-cell IRS/metasurface for phase control, beam steering, or wireless propagation studies.

### 10. Reference
F. Liu et al., "Intelligent Metasurfaces with Continuously Tunable Local Surface Impedance for Multiple Reconfigurable Functions," Physical Review Applied, vol. 11, 044024, 2019.

DOI: 10.1103/PhysRevApplied.11.044024
