# Submission Notes

## What this repository currently proves

The supplied reference paper supports the geometry, material parameters, R-C concept, HFSS methodology, and published benchmark.

## What must come from the student's own HFSS work

Before calling the repository a record of an independently performed simulation, add:

1. Your `.aedt` project file (if allowed by your course/lab).
2. HFSS 3D-model screenshot.
3. Boundary-condition screenshot.
4. Floquet-port screenshot.
5. Solution-setup screenshot.
6. Actual S11 export.
7. Actual S11 plot.
8. Any R/C sweep data.
9. A short comparison between your result and the paper.

## Do not do this

Do not copy the paper's −59.4 dB result into a file named as your own simulation result.

Instead, call it:

`reference_benchmark.csv`

and cite the paper.

## Suggested GitHub project description

> Designed and simulated a single Intelligent Reflecting Surface (IRS) / intelligent metasurface unit cell in ANSYS HFSS based on a published tunable metasurface architecture operating around 5 GHz.
