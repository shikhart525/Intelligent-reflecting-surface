# ANSYS HFSS Simulation Workflow

## 1. Define design variables

Suggested variables based on the reference design:

```text
dx = 9.12mm
dy = 18.24mm
w  = 8.12mm
g  = 1mm
t  = 1.016mm
R  = 3.44ohm
C  = 1.69pF
f0 = 5GHz
```

## 2. Materials

### Substrate
Rogers RT/Duroid 5880:
- Relative permittivity = 2.2
- Loss tangent = 0.0009

### Conductors
Use copper for the metallic layers.

## 3. Geometry

Create:
- dielectric substrate
- bottom continuous ground
- two top square patches
- 1 mm gap between the patches
- lumped R-C connection across the gap

## 4. Boundary Conditions

For an infinite periodic unit-cell model, use the appropriate HFSS periodic/unit-cell boundary configuration.

## 5. Excitation

Use a Floquet port and define the required polarization/incidence condition.

## 6. Solution Setup

Use a solution frequency around:

```text
5 GHz
```

Perform a frequency sweep around the target frequency.

## 7. Main Output

Export:

```text
Frequency
S11 magnitude in dB
```

The preferred CSV format for this repository is:

```text
Frequency_GHz,S11_dB
```

Save it as:

```text
results/S11.csv
```

## 8. Recommended Additional Sweeps

For a stronger project, perform:
- C sweep while keeping R fixed
- R sweep while keeping C fixed
- frequency sweep
- incidence-angle sweep if your HFSS setup supports it

## 9. Final Evidence

The GitHub repository should contain screenshots of:
- complete 3D model
- material assignment
- lumped R-C element
- boundary conditions
- Floquet port
- solution setup
- S11 plot
- final simulated geometry
