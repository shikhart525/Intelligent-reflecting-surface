# Results

Put your **actual ANSYS HFSS exported S11 data** here.

Recommended filename:

`S11.csv`

Required columns:

```text
Frequency_GHz,S11_dB
```

The repository does not contain a fabricated HFSS curve. The paper's reported -59.4 dB value is stored separately as `reference_benchmark.csv`.
