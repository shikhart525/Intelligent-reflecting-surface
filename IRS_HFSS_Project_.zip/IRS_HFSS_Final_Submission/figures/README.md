# Figures

Add your actual HFSS screenshots here, for example:

- `01_unit_cell_3d.png`
- `02_material_setup.png`
- `03_boundary_conditions.png`
- `04_floquet_port.png`
- `05_solution_setup.png`
- `06_s11_result.png`
- `07_parametric_sweep.png`
